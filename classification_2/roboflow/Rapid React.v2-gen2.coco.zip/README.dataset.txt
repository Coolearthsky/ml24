# Rapid React > Gen2
https://universe.roboflow.com/ryder/rapid-react-qn5ug

Provided by a Roboflow user
License: CC BY 4.0

Dataset for object detection with cargo from 2022 First Robotics Competition Rapid React.